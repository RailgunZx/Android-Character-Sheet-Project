package com.example.charactersheetempty

import androidx.lifecycle.*
import kotlinx.coroutines.launch


class CharacterViewModel(private val repository: CharacterRepository): ViewModel() {


    val allCharacters: LiveData<Map<Int,CharacterItem>> = repository.allCharacters.asLiveData()

    class CharacterViewModelFactory(private val repository: CharacterRepository) : ViewModelProvider.Factory{
        override fun <T: ViewModel> create(modelClass: Class<T>): T{
            if(modelClass.isAssignableFrom(CharacterViewModel::class.java)){
                @Suppress("UNCHECKED_CAST")
                return CharacterViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel Class")
        }
    }


}